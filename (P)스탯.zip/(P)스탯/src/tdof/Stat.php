<?php
namespace tdof;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use tdof\equip\Equip;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\item\Tool;

class Stat extends PluginBase implements Listener
{

    private $data, $db;

    private $prefix = "§l§6[스탯] §r§7";

    private $formIds = [];

    private static $instance = null;

    public function addButton($modal, $text, $imageType = -1, $imagePath = "")
    {
        $content = [
            "text" => $text
        ];
        if ($imageType !== - 1) {
            $content["image"]["type"] = $imageType === 0 ? "path" : "url";
            $content["image"]["data"] = $imagePath;
        }
        $modal['buttons'][] = $content;
        return $modal;
    }

    public function randomID()
    {
        return mt_rand(5223, 9123);
    }

    public function sendStatUI(Player $player)
    {
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다."
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8스탯 올리기\n§d* §f다양한 스탯을 올려보세요!");
        $modal = $this->addButton($modal, "§8내정보 보기\n§d* §f나의 스탯 정보를 봅니다.");
        $modal = $this->addButton($modal, "§8스탯 설명보기\n§d* §f스탯의 설명을 확인합니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12004;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "main";
    }

    public function onItemHeld(PlayerItemHeldEvent $event)
    {
        $player = $event->getPlayer();
        $this->setMaxHP($player);
    }

    public function sendStatUpListUI(Player $player)
    {
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다."
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8힘 스탯 올리기\n§d* §f힘 스탯을 올립니다.");
        $modal = $this->addButton($modal, "§8방어 스탯 올리기\n§d* §f방어 스탯을 올립니다.");
        $modal = $this->addButton($modal, "§8체력 스탯 올리기\n§d* §f체력 스탯을 올립니다.");
        $modal = $this->addButton($modal, "§8행운 스탯 올리기\n§d* §f행운 스탯을 올립니다.");
        $modal = $this->addButton($modal, "§8크리티컬 스탯 올리기\n§d* §f크리티컬 스탯을 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12005;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "stat_up_list";
    }

    public function sendStrUpUI(Player $player)
    {
        $left = $this->getStat($player);
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다.\n\n{$player->getName()} 님의 남은 스탯: {$left}"
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8창 종료하기\n§d* §f창을 종료합니다.");
        $modal = $this->addButton($modal, "§8힘 스탯 1 올리기\n§d* §f힘 스탯을 1 올립니다.");
        $modal = $this->addButton($modal, "§8힘 스탯 10 올리기\n§d* §f힘 스탯을 10 올립니다.");
        $modal = $this->addButton($modal, "§8힘 스탯 50 올리기\n§d* §f힘 스탯을 50 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12006;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "str_up";
    }

    public function sendDexUpUI(Player $player)
    {
        $left = $this->getStat($player);
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다.\n\n{$player->getName()} 님의 남은 스탯: {$left}"
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8창 종료하기\n§d* §f창을 종료합니다.");
        $modal = $this->addButton($modal, "§8방어 스탯 1 올리기\n§d* §f방어 스탯을 1 올립니다.");
        $modal = $this->addButton($modal, "§8방어 스탯 10 올리기\n§d* §f방어 스탯을 10 올립니다.");
        $modal = $this->addButton($modal, "§8방어 스탯 50 올리기\n§d* §f방어 스탯을 50 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12007;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "dex_up";
    }

    public function sendHpUpUI(Player $player)
    {
        $left = $this->getStat($player);
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다.\n\n{$player->getName()} 님의 남은 스탯: {$left}"
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8창 종료하기\n§d* §f창을 종료합니다.");
        $modal = $this->addButton($modal, "§8체력 스탯 1 올리기\n§d* §f체력 스탯을 1 올립니다.");
        $modal = $this->addButton($modal, "§8체력 스탯 10 올리기\n§d* §f체력 스탯을 10 올립니다.");
        $modal = $this->addButton($modal, "§8체력 스탯 50 올리기\n§d* §f체력 스탯을 50 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12008;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "hp_up";
    }

    public function sendLukUpUI(Player $player)
    {
        $left = $this->getStat($player);
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다.\n\n{$player->getName()} 님의 남은 스탯: {$left}"
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8창 종료하기\n§d* §f창을 종료합니다.");
        $modal = $this->addButton($modal, "§8행운 스탯 1 올리기\n§d* §f행운 스탯을 1 올립니다.");
        $modal = $this->addButton($modal, "§8행운 스탯 10 올리기\n§d* §f행운 스탯을 10 올립니다.");
        $modal = $this->addButton($modal, "§8행운 스탯 50 올리기\n§d* §f행운 스탯을 50 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12009;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "luk_up";
    }

    public function sendCtkUpUI(Player $player)
    {
        $left = $this->getStat($player);
        $modal = [
            "type" => "form",
            "title" => "§e§l§p< §f스탯 §e>",
            "content" => "§l§f스탯 UI입니다.\n\n{$player->getName()} 님의 남은 스탯: {$left}"
        ];
        $modal['buttons'] = [];
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $modal = $this->addButton($modal, "§8창 종료하기\n§d* §f창을 종료합니다.");
        $modal = $this->addButton($modal, "§8크리티컬 스탯 1 올리기\n§d* §f크리티컬 스탯을 1 올립니다.");
        $modal = $this->addButton($modal, "§8크리티컬 스탯 10 올리기\n§d* §f크리티컬 스탯을 10 올립니다.");
        $modal = $this->addButton($modal, "§8크리티컬 스탯 50 올리기\n§d* §f크리티컬 스탯을 50 올립니다.");
        $modal = $this->addButton($modal, "§l§d- - - - - - - - - - - - - - - - - -");
        $pk = new ModalFormRequestPacket();
        $pk->formId = 12010;
        $pk->formData = json_encode($modal);
        $player->dataPacket($pk);
        $this->formIds[strtolower($player->getName())] = "ctk_up";
    }

    public function onReceive(DataPacketReceiveEvent $event)
    {
        $pk = $event->getPacket();
        if ($pk instanceof ModalFormResponsePacket) {
            $player = $event->getPlayer();
            if (isset($this->formIds[strtolower($player->getName())])) {
                $type = $pk->formId;
                if ($type == 12004) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 1) {
                            $this->sendStatUpListUI($player);
                        } elseif ($data == 2) {
                            $all_e = Equip::getInstance()->getAllStatus($player);
                            $str = $this->getSTR($player->getName());
                            $str += $all_e[0];
                            $dex = $this->getDEX($player->getName());
                            $dex += $all_e[1];
                            $hp = $this->getHP($player->getName());
                            $hp += $all_e[2];
                            $luk = $this->getLUK($player->getName());
                            $luk += $all_e[3];
                            $ctk = $this->getCTK($player->getName());
                            $ctk += $all_e[4];
                            $strdata = "§l§fSTR => §c" . str_repeat("|", (int) $str / 5) . "§f ({$str})";
                            $dexdata = "§l§fDEX => §b" . str_repeat("|", (int) $dex / 5) . "§f ({$dex})";
                            $hpdata = "§l§f HP  => §a" . str_repeat("|", (int) $hp / 5) . "§f ({$hp})";
                            $lukdata = "§l§fLUK => §e" . str_repeat("|", (int) $luk / 5) . "§f ({$luk})";
                            $ctkdata = "§l§fCTK => §4" . str_repeat("|", (int) $ctk / 5) . "§f ({$ctk})";
                            $leftStat = $this->getStat($player->getName());
                            $canHandedStats = $this->getMaxHanded($player->getName()) - $this->getHanded($player->getName());
                            UIMessage::getInstance()->sendUI($player, "§6§l내 스탯정보 §f창", "§l§d- - - - - - - - - - - - - - - - -\n\n§f남은 스탯: {$leftStat}, 찍을 수 있는 수탯: {$canHandedStats}\n\n{$strdata}\n{$dexdata}\n{$hpdata}\n{$lukdata}\n{$ctkdata}\n\n§l§d- - - - - - - - - - - - - - - - -");
                        } elseif ($data == 3) {
                            UIMessage::getInstance()->sendUI($player, "§l§f스탯 목록", "§l§f[§c STR§f : 이 스탯을 찍을 시 공격력 상승 §f]\n§l§f[ §bDEX§f : 이 스탯을 찍을 시 방어력 상승 §f]\n§l§f[ §aHP §f: 이 스탯을 찍을 시 체력 상승 §f]\n§l§f[ §eLUK §f: 이 스탯을 찍을 시 회피율 상승 §f]\n§l§f[ §4CTK §f: 이 스탯을 찍을 시 크리티컬 확률 상승 §f]");
                        }
                    }
                } elseif ($type == 12005) {
                    $data = json_decode($pk->formData, true);
                    if ($data == 1) {
                        $this->sendStrUpUI($player);
                    } elseif ($data == 2) {
                        $this->sendDexUpUI($player);
                    } elseif ($data == 3) {
                        $this->sendHpUpUI($player);
                    } elseif ($data == 4) {
                        $this->sendLukUpUI($player);
                    } elseif ($data == 5) {
                        $this->sendCtkUpUI($player);
                    }
                } elseif ($type == 12010) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 2) {
                            $left = $this->getStat($player);
                            if ($left >= 1) {
                                $this->Up($player, "ctk", 1);
                                $this->sendCtkUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 3) {
                            $left = $this->getStat($player);
                            if ($left >= 10) {
                                $this->Up($player, "ctk", 10);
                                $this->sendCtkUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 4) {
                            $left = $this->getStat($player);
                            if ($left >= 50) {
                                $this->Up($player, "ctk", 50);
                                $this->sendCtkUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        }
                    }
                } elseif ($type == 12009) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 2) {
                            $left = $this->getStat($player);
                            if ($left >= 1) {
                                $this->Up($player, "luk", 1);
                                $this->sendLukUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 3) {
                            $left = $this->getStat($player);
                            if ($left >= 10) {
                                $this->Up($player, "luk", 10);
                                $this->sendLukUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 4) {
                            $left = $this->getStat($player);
                            if ($left >= 50) {
                                $this->Up($player, "luk", 50);
                                $this->sendLukUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        }
                    }
                } elseif ($type == 12008) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 2) {
                            $left = $this->getStat($player);
                            if ($left >= 1) {
                                $this->Up($player, "hp", 1);
                                $this->sendHpUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 3) {
                            $left = $this->getStat($player);
                            if ($left >= 10) {
                                $this->Up($player, "hp", 10);
                                $this->sendHpUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 4) {
                            $left = $this->getStat($player);
                            if ($left >= 50) {
                                $this->Up($player, "hp", 50);
                                $this->sendHpUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        }
                    }
                } elseif ($type == 12007) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 2) {
                            $left = $this->getStat($player);
                            if ($left >= 1) {
                                $this->Up($player, "dex", 1);
                                $this->sendDexUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 3) {
                            $left = $this->getStat($player);
                            if ($left >= 10) {
                                $this->Up($player, "dex", 10);
                                $this->sendDexUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 4) {
                            $left = $this->getStat($player);
                            if ($left >= 50) {
                                $this->Up($player, "dex", 50);
                                $this->sendDexUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        }
                    }
                } elseif ($type == 12006) {
                    $data = json_decode($pk->formData, true);
                    if ($data !== null) {
                        if ($data == 2) {
                            $left = $this->getStat($player);
                            if ($left >= 1) {
                                $this->Up($player, "str", 1);
                                $this->sendStrUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 3) {
                            $left = $this->getStat($player);
                            if ($left >= 10) {
                                $this->Up($player, "str", 10);
                                $this->sendStrUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        } elseif ($data == 4) {
                            $left = $this->getStat($player);
                            if ($left >= 50) {
                                $this->Up($player, "str", 50);
                                $this->sendStrUpUI($player);
                            } else {
                                $player->sendMessage($this->prefix . "스탯이 부족합니다.");
                            }
                        }
                    }
                }
            }
        }
    }

    public function onLoad()
    {
        if (self::$instance == null)
            self::$instance = $this;
    }

    public static function getInstance()
    {
        return static::$instance;
    }

    public function onJoinAndSetHealth(PlayerJoinEvent $event)
    {
        $pl = $event->getPlayer();
        $this->setMaxHP($pl);
    }

    public function onEnable()
    {
        @mkdir($this->getDataFolder());
        $this->data = new Config($this->getDataFolder() . "Data.yml", Config::YAML, [
            "stats" => []
        ]);
        $this->db = $this->data->getAll();
        $this->getServer()
            ->getPluginManager()
            ->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        $command = $command->getName();
        if ($command == "스탯" || $command == "스텟") {
            if ($sender instanceof Player) {
                $this->sendStatUI($sender);
            } else {
                $sender->sendMessage($this->prefix . "인게임에서 실행하세요.");
            }
        }
        return true;
        /*
         * if (! isset($args[0]))
         * $args[0] = 'x';
         * switch ($args[0]) {
         * case "스탯권":
         * if (! $sender->isOp())
         * return true;
         * $this->createStatUpCoupon($sender);
         * break;
         * case "내정보":
         * if ($sender instanceof Player) {
         * $all_e = Equip::getInstance()->getAllStatus($sender);
         * $args[1] = $sender->getName();
         * $str = $this->getSTR($args[1]);
         * $str += $all_e[0];
         * $dex = $this->getDEX($args[1]);
         * $dex += $all_e[1];
         * $hp = $this->getHP($args[1]);
         * $hp += $all_e[2];
         * $luk = $this->getLUK($args[1]);
         * $luk += $all_e[3];
         * $ctk = $this->getCTK($args[1]);
         * $ctk += $all_e[4];
         * $strdata = "§l§fSTR => §c" . str_repeat("|", (int) $str / 5) . "§f ({$str})";
         * $dexdata = "§l§fDEX => §b" . str_repeat("|", (int) $dex / 5) . "§f ({$dex})";
         * $hpdata = "§l§f HP => §a" . str_repeat("|", (int) $hp / 5) . "§f ({$hp})";
         * $lukdata = "§l§fLUK => §e" . str_repeat("|", (int) $luk / 5) . "§f ({$luk})";
         * $ctkdata = "§l§fCTK => §4" . str_repeat("|", (int) $ctk / 5) . "§f ({$ctk})";
         * $leftStat = $this->getStat($args[1]);
         * $canHandedStats = $this->getMaxHanded($args[1]) - $this->getHanded($args[1]);
         * $sender->sendMessage("§l§f=====> {$args[1]} 님 ======>\n{$strdata}\n{$dexdata}\n{$hpdata}\n{$lukdata}\n{$ctkdata}\n§l§f남은 스탯: {$leftStat}, 올릴수 있는 스탯: {$canHandedStats}");
         * }
         * break;
         * case "보기":
         * if (! isset($args[1])) {
         * $sender->sendMessage($this->prefix . "/스탯 보기 [닉네임]");
         * return true;
         * }
         * if ($this->getServer()->getPlayer($args[1]) !== null) {
         * $player = $this->getServer()->getPlayer($args[1]);
         * $args[1] = $this->getServer()
         * ->getPlayer($args[1])
         * ->getName();
         * $all_e = Equip::getInstance()->getAllStatus($player);
         * }
         * $str = $this->getSTR($args[1]);
         * $dex = $this->getDEX($args[1]);
         * $hp = $this->getHP($args[1]);
         * $luk = $this->getLUK($args[1]);
         * $ctk = $this->getCTK($args[1]);
         * if (isset($all_e)) {
         * $str += $all_e[0];
         * $dex += $all_e[1];
         * $hp += $all_e[2];
         * $luk += $all_e[3];
         * $ctk += $all_e[4];
         * }
         * $strdata = "§l§fSTR => §c" . str_repeat("|", (int) $str / 5) . "§8" . str_repeat("|", (int) 30 - $str / 5) . "§f ({$str}/150)";
         * $dexdata = "§l§fDEX => §b" . str_repeat("|", (int) $dex / 5) . "§8" . str_repeat("|", (int) 30 - $dex / 5) . "§f ({$dex}/150)";
         * $hpdata = "§l§f HP => §a" . str_repeat("|", (int) $hp / 5) . "§8" . str_repeat("|", (int) 30 - $hp / 5) . "§f ({$hp}/150)";
         * $lukdata = "§l§fLUK => §e" . str_repeat("|", (int) $luk / 5) . "§8" . str_repeat("|", (int) 30 - $luk / 5) . "§f ({$luk}/150)";
         * $ctkdata = "§l§fCTK => §4" . str_repeat("|", (int) $ctk / 5) . "§8" . str_repeat("|", (int) 30 - $ctk / 5) . "§f ({$ctk}/150)";
         * $leftStat = $this->getStat($args[1]);
         * $canHandedStats = $this->getMaxHanded($args[1]) - $this->getHanded($args[1]);
         * $sender->sendMessage("§l§f=====> {$args[1]} 님 ======>\n{$strdata}\n{$dexdata}\n{$hpdata}\n{$lukdata}\n{$ctkdata}\n§l§f남은 스탯: {$leftStat}, 올릴수 있는 스탯: {$canHandedStats}");
         * break;
         * case "올리기":
         * case "찍기":
         * if (! $sender instanceof Player) {
         * $sender->sendMessage($this->prefix . "인게임에서 실행하십시오.");
         * return true;
         * }
         * if (! isset($args[1])) {
         * $sender->sendMessage($this->prefix . "/스탯 올리기 [힘|방어|체력|회피|크리티컬] [올릴양]");
         * return true;
         * }
         * if (! isset($args[2])) {
         * $sender->sendMessage($this->prefix . "/스탯 올리기 [힘|방어|체력|회피|크리티컬] [올릴양]");
         * return true;
         * }
         * if (! is_numeric($args[2])) {
         * $sender->sendMessage($this->prefix . "올릴양은 숫자로 입력해주어야 합니다.");
         * return true;
         * }
         * $array = [
         * "힘" => "str",
         * "방어" => "dex",
         * "체력" => "hp",
         * "회피" => "luk",
         * "크리티컬" => "ctk"
         * ];
         * if (isset($array[$args[1]])) {
         * $option = $array[$args[1]];
         * $handed = $this->getHanded($sender);
         * $maxHanded = $this->getMaxHanded($sender);
         * $leftStat = $this->getStat($sender);
         * if ($leftStat >= $args[2]) {
         * if ($maxHanded >= $handed + $args[2]) {
         * $this->Up($sender, $option, $args[2]);
         * if ($option == "hp") {
         * $this->setMaxHP($sender);
         * }
         * $sender->sendMessage($this->prefix . "{$args[1]} 스탯 §l§a{$args[2]}개§r§f를 찍었습니다.");
         * } else {
         * $sender->sendMessage($this->prefix . "당신은 더 이상 스탯을 찍을 수 없습니다.");
         * }
         * } else {
         * $sender->sendMessage($this->prefix . "스탯을 올릴 수 없습니다. (스탯부족)");
         * }
         * } else {
         * $sender->sendMessage($this->prefix . "/스탯 올리기 [힘|방어|체력|회피|크리티컬] [올릴양]");
         * }
         * break;
         * default:
         * $sender->sendMessage($this->prefix . "/스탯 올리기 [힘|방어|체력|회피|크리티컬] [올릴양]");
         * $sender->sendMessage($this->prefix . "/스탯 내정보");
         * $sender->sendMessage($this->prefix . "/스탯 보기 [닉네임]");
         * break;
         * }
         * return true;
         * }
         * return true;
         */
    }

    public function useStatUpCoupon(Player $player)
    {
        $name = strtolower($player->getName());
        $this->db["stats"][$name]["stat"] += 10;
    }

    public function createStatUpCoupon(Player $player)
    {
        $player->getInventory()->addItem(Item::get(421, 0, 1)->setCustomName("스탯 10 획득권"));
    }

    public function onInteract(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        if ($event->getAction() == $event::LEFT_CLICK_BLOCK || $event->getAction() == $event::RIGHT_CLICK_BLOCK) {
            $inv = $player->getInventory();
            $hand = $inv->getItemInHand();
            if ($hand->getCustomName() == "스탯 10 획득권") {
                $this->useStatUpCoupon($player);
                $inv->removeItem(Item::get($hand->getId(), $hand->getDamage(), 1));
            }
        }
    }

    public function critical(float $damage)
    {
        $rand = mt_rand(15, 22);
        $rand = (float) $rand / 10;
        $damage = $damage * $rand;
        return $damage;
    }

    public function setMaxHP(Player $player)
    {
        $hp = $this->getHP($player);
       $player_allEquip = Equip::getInstance()->getAllStatus($player);
        $hp += $player_allEquip[2];
       $max = 30 + $hp / 35;
        $player->setMaxHealth($max);
    }

    private $sec = [];

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        if (! isset($this->db["stats"][strtolower($player->getName())])) {
            $playerName = strtolower($player->getName());
            $this->db["stats"][$playerName] = [
                "defaultStat" => [
                    "str" => 5,
                    "dex" => 5,
                    "hp" => 5,
                    "luk" => 5,
                    "ctk" => 5
                ],
                "stat" => 0,
                "str" => 0,
                "dex" => 0,
                "hp" => 0,
                "luk" => 0,
                "ctk" => 0,
                "handed" => 0,
                "max-handed" => 250
            ];
        }
    }

    public function increaseMaxHanded($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            if ($this->db["stats"][$name]["max-handed"] < 150) {
                $this->db["stats"][$name]["max-handed"] += 10;
                return true;
            }
            return false;
        }
        return false;
    }

    public function setDefaultStat($player, array $data)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            $this->db["stats"][$name]["defaultStat"] = $data;
            return true;
        }
        return false;
    }

    public function getHanded($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["handed"];
        }
        return false;
    }

    public function getMaxHanded($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["max-handed"];
        }
        return false;
    }

    public function Up($player, $option, $count, $handed = true)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            if ($this->getHanded($player) < $this->getMaxHanded($player)) {
                if ($this->getHanded($player) + $count <= $this->getMaxHanded($player)) {
                    $s = $this->db["stats"][$name][$option];
                    if ($s + $count > 150)
                        return false;
                    $this->db["stats"][$name][$option] += $count;
                    if ($handed)
                        $this->db["stats"][$name]["stat"] -= $count;
                    if ($handed)
                        $this->db["stats"][$name]["handed"] += $count;
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    // 당신은 더 이상 스탯을 찍을 수 없습니다.
    public function Down($player, $option, $count, $handed = true)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            $this->db["stats"][$name][$option] -= $count;
            return true;
        }
    }

    public function setStat($player, int $stat)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            $this->db["stats"][$name]["stat"] = $stat;
        }
    }

    public function getStat($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["stat"];
        }
    }

    public function getSTR($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["str"] + $this->db["stats"][$name]["defaultStat"]["str"];
        }
    }

    public function getDEX($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["dex"] + $this->db["stats"][$name]["defaultStat"]["dex"];
        }
    }

    public function getHP($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["hp"] + $this->db["stats"][$name]["defaultStat"]["hp"];
        }
    }

    public function getLUK($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["luk"] + $this->db["stats"][$name]["defaultStat"]["luk"];
        }
    }

    public function getCTK($player)
    {
        if ($player instanceof Player)
            $player = $player->getName();
        $name = strtolower($player);
        if (isset($this->db["stats"][$name])) {
            return $this->db["stats"][$name]["ctk"] + $this->db["stats"][$name]["defaultStat"]["ctk"];
        }
    }

    public function onDisable()
    {
        $this->data->setAll($this->db);
        $this->data->save();
    }
}